# AI-Based Job Recommendation System

Bidhayak Baral — Data Science Capstone, 2026

This archive contains the original Streamlit application, TF-IDF recommendation
engine, job-source adapters, and human-judgment evaluation code. Private resume
submissions, API keys, caches, and source datasets are excluded.

## Run the full application

Install Python 3.11 or newer. From this folder:

    python -m venv .venv
    # Activate the environment, then:
    python -m pip install -r requirements.txt
    python -m streamlit run app.py

On Windows, start_app.bat can create the environment and launch the app.

Use your own job CSV and resume, or configure the supported job APIs in the app.
Obtain any required API credentials from the providers and enter them locally.
No credentials are included in this archive.

## Method

The engine normalizes text, weights job titles twice, uses unigram/bigram TF-IDF,
and ranks by cosine similarity. Shared terms, matched skills, and missing skills
explain the results. Skill explanations do not change the cosine ranking.

The evaluation module calculates Precision@K, nDCG@K, and mean reciprocal rank
from human relevance judgments. No accuracy or hiring-success rate is claimed.

## Browser edition

The portfolio's browser edition executes extracted, unchanged ranking classes
and helpers in Pyodide. It adds a lightweight web interface, example roles,
text-resume input, and optional job CSV input. Its small-corpus configuration
uses min_df=1 and max_df=1.0. The full Streamlit interface and live job API
integrations are available when running this original project locally.
